#pragma once

#define CC_MARK_USED_VAR(v) static_cast<void>(v)
