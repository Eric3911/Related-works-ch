# /bin/bash -e
set -x
rm -rf ./build* ./output ./config ./model/benchmark* ./model/generate*
