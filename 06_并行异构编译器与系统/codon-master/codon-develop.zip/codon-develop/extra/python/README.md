To install:

```bash
$ pip install .
```

If Codon is installed in non-standard directory, please set `CODON_DIR` accordingly.

To use:

```python
import codon

@codon.jit
def ...
```
