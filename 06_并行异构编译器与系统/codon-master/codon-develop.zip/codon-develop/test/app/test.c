extern void foo(long);
int main(void) { foo(3); }
