triton
======

.. currentmodule:: triton

.. autosummary::
    :toctree: generated
    :nosignatures:

    jit
    autotune
    heuristics
    Config
