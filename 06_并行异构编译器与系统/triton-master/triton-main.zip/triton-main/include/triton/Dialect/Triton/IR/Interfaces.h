#ifndef TRITON_IR_INTERFACES_H_
#define TRITON_IR_INTERFACES_H_

#include "mlir/IR/OpDefinition.h"

#define GET_TYPEDEF_CLASSES
#include "triton/Dialect/Triton/IR/AttrInterfaces.h.inc"

#endif // TRITON_IR_TYPES_H_
