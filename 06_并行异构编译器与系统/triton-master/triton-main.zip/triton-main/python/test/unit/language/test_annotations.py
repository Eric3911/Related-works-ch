
from __future__ import annotations

import torch

import triton
import triton.language as tl


def test_annotations():

    @triton.jit
    def _kernel(X: torch.Tensor, N: int, BLOCK_SIZE: tl.constexpr):
        pass

    x = torch.empty(1, device='cuda')
    _kernel[(1,)](x, x.shape[0], 32)
    try:
        _kernel[(1,)](x.shape[0], x.shape[0], 32)
    except AttributeError:
        pass
