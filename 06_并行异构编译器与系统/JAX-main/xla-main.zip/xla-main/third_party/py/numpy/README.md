# numpy_ops

The folder tf_numpy_api/ contains lists of NumPy API symbols that the
`numpy_ops` internal module in TensorFlow implements.
