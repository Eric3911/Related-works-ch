This sub-directory contains third-party code for which Google does not have
copyright. Each sub-directory should correspond to a third-party library and
must contain the appropriate LICENSE file. 
See [instructions](https://opensource.google/docs/releasing/preparing/#third-party-components).
