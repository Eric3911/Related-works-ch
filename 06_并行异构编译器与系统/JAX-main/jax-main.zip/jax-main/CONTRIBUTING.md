# Contributing to JAX

For information on how to contribute to JAX, see
[Contributing to JAX](https://jax.readthedocs.io/en/latest/contributing.html)
