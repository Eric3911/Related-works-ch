
``jax.typing`` module
=====================

.. automodule:: jax.typing

List of Members
---------------

.. autosummary::
  :toctree: _autosummary

    ArrayLike
