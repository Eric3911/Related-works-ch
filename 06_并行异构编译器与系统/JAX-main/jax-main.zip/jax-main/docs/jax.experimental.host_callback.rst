``jax.experimental.host_callback`` module
=========================================


.. automodule:: jax.experimental.host_callback

API
---

.. autosummary::
   :toctree: _autosummary

   id_tap
   id_print
   call
   barrier_wait
   CallbackException



