More documentation see:

- [AutoSearch中文文档](https://autokernel-docs-en.readthedocs.io/zh_CN/latest/tutorials/autosearch.html)
- [AutoSearch Doc](https://autokernel-docs-en.readthedocs.io/en/latest/tutorials/autosearch.html)
